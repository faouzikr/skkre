# GUI_Masscan

<img src=http://s10.picofile.com/file/8406785276/photo_2020_08_26_03_47_08.jpg></br>
</br>
This repository contains compiled version of Masscan using visual studio 2015.</br>
</br>
Visual Studio 2015 Support provided by https://github.com/kjacobsen/masscan.</br>
</br>
Compiled at https://github.com/kjacobsen/masscan/commit/d2f8c4264edf16f179d9968c759ed6884ae371e2</br>
</br>
Neshta Virus Removed!
